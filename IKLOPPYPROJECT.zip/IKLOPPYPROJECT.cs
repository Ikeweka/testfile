﻿using System;

namespace IK_LOOPY
{
    class Program
    {
        public static int menuchoice;    // Menu number to be input
        public static double weight;     // Weight(pound) number to be input
        public static void printMenu()
        {
            Console.WriteLine("           Menu of Planets          ");   //List of Planets to be input
            Console.WriteLine("           ==== == =======          ");
            Console.WriteLine("1. Jupiter    2. Mars     3. Mercury");
            Console.WriteLine("4. Neptune    5. Pluto    6. Saturn ");
            Console.WriteLine("7. Uranus     8. Venus    9. <Quit> ");
        }
         
    static void Main(string[] args)

        {
            do
            {
                if (menuchoice < 0)  //if the menuchoice is less than zero prompt default to run 
                { 
                    Console.WriteLine();
                }
                else
                    printMenu();
                Console.WriteLine("\nEnter your menu choice ");   //This is string input
                menuchoice = int.Parse(Console.ReadLine());      // Convert to interger

                Console.WriteLine("\nyour menu choice is: {0}", menuchoice);    
                {
                    if (weight < 0)  //if the weight is less thsn zero the prompt default to run
                    {
                        Console.WriteLine();
                    }
                    else

                        Console.WriteLine("\nEnter your weight on earth ");    //This is string input
                weight = double.Parse(Console.ReadLine());                    //Converts  to double
                Console.WriteLine("\nyour weight on earth is: {0}", weight);

                    switch (menuchoice)   //Switch the case for each menuchoice
                    {
                        case 1:
                            Console.WriteLine("\nyour weight of " + weight + " pounds on Earth is " + 2.64 *
                                weight + " pounds on Jupiter");
                            break;
                        case 2:
                            Console.WriteLine("\nyour weight of  " + weight + " pounds on Earth is " + 0.38 *
                                weight + " pounds on Mars");
                            break;
                        case 3:
                            Console.WriteLine("\nyour weight of  " + weight + " pounds on Earth is " + 0.37 *
                                weight + " pounds on Mercury");
                            break;
                        case 4:
                            Console.WriteLine("\nyour weight of  " + weight + " pounds on Earth is " + 1.12 *
                                 weight + " pounds on Neptune");
                            break;
                        case 5:
                            Console.WriteLine("\nyour weight of  " + weight + " pounds on Earth is " + 0.04 *
                                 weight + " pounds on Pluto");
                            break;
                        case 6:
                            Console.WriteLine("\nyour weight of  " + weight + " pounds on Earth is " + 1.15 *
                                  weight + " pounds on Saturn");
                            break;
                        case 7:
                            Console.WriteLine("\nyour weight of  " + weight + " pounds on Earth is " + 1.15 *
                                 weight + " pounds on Uranus");
                            break;
                        case 8:
                            Console.WriteLine("\nyour weight of  " + weight + " pounds on Earth is " + 0.88 *
                                weight + " pounds on Venus");
                            break;
                        case 9:
                            Console.WriteLine("\nNice having you around.GoodBye\n"); //End of loop
                            break;
                        default:
                            Console.WriteLine("\nPLEASE ENTER A NUMBER BETWEEN 1-9\n"); //Default when an input number does not fall between 1-9
                            break;
                    }
                }

            } while (menuchoice != 9); //prompts the code to only loop till case 9


            Console.ReadLine(); //Displays the user input

        }
    }
}

